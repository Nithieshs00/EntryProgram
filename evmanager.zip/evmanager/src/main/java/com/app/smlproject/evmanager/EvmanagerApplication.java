package com.app.smlproject.evmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvmanagerApplication.class, args);
	}

}
